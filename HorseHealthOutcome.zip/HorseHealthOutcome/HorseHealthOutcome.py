#Exercise can be found here: https://www.kaggle.com/competitions/playground-series-s3e22/overview
#Managing Imports
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import scipy.stats as stats
import sklearn
import seaborn as sns
from catboost import CatBoostClassifier, Pool
from sklearn import linear_model
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, GradientBoostingClassifier
from sklearn.feature_selection import mutual_info_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, mean_squared_error, mean_absolute_error, cohen_kappa_score, f1_score
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.multiclass import OneVsRestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier, BernoulliRBM
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder, OneHotEncoder, LabelEncoder, MinMaxScaler, StandardScaler, Normalizer, power_transform
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from xgboost import XGBClassifier

#Categorical data prep
def dataPrepFirst(X):   #Done with test and train together (although it's rather unrealistic)
    #Dropping unecessary features
    X = X.drop(["hospital_number", "id", "surgical_lesion", "cp_data"], axis=1)

    #Creating a feature listing the number of lesions (to replace the one removed above)
    X["number_of_lesions"] = (X["lesion_1"].gt(0) * 1) + (X["lesion_2"].gt(0) * 1) + (X["lesion_3"].gt(0) * 1)
    
    X = X.replace(np.nan, "nan")    #To make replacement of values with the ordinal encoder easier
    #Ordinal Encoding
    #https://datascience.stackexchange.com/questions/72343/encoding-with-ordinalencoder-how-to-give-levels-as-user-input
    #Dictionary of cardinal data (ranked based on Stats.txt)
    #Test data has moderate pain, training data does not
    catDict = {"temp_of_extremities": ["cold", "cool", "nan", "warm", "normal"],
                     "peripheral_pulse": ["nan", "absent", "reduced", "increased", "normal"],
                     "mucous_membrane": ["dark_cyanotic", "pale_cyanotic", "bright_red", "nan", "bright_pink", "pale_pink", "normal_pink"],
                     "capillary_refill_time": ["nan", "more_3_sec", "3", "less_3_sec"],
                     "pain": ["extreme_pain", "severe_pain", "nan", "slight", "depressed", "mild_pain", "alert"],
                     "peristalsis": ["distend_small", "nan", "absent", "hypomotile", "normal", "hypermotile"],
                     "abdominal_distention": ["severe", "nan", "moderate", "slight", "none"],
                     "nasogastric_tube": ["nan", "significant", "none", "slight"],
                     "nasogastric_reflux": ["more_1_liter", "nan", "slight", "less_1_liter", "none"],
                     "rectal_exam_feces": ["serosanguious", "absent", "nan", "decreased", "increased", "normal"],
                     "abdomen": ["distend_large", "nan", "distend_small", "normal", "firm", "other"],
                     "abdomo_appearance": ["serosanguious", "nan", "cloudy", "clear"]}
    for i in catDict:
        OrdEncoder = OrdinalEncoder(categories=[catDict[i]], handle_unknown="use_encoded_value", unknown_value=-1)
        X[i] = OrdEncoder.fit_transform(X[[i]])

    #One Hot Encoder
    OHEncoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    toOHE = ["age", "surgery"]
    OHEncoded = pd.DataFrame(OHEncoder.fit_transform(X[toOHE]))
    OHEncoded.index = X.index
    X = X.drop(toOHE, axis=1)
    X = pd.concat([X, OHEncoded], axis=1)

    #Changing lesion info
    #First number: 00-11 | Second: 1-4 | Third: 0-2 | Fourth: 0-10
    #Need to change single digit 0's to multidigit 0000's. Those starting in 00 have 0 for the third and fourth numbers too
    for i in range(1,4):    #Selecting the range of lesions (1-3)
        postSplit = X[f"lesion_{i}"].astype(str).str.zfill(5).apply(properlySplittingLesions)   #Filling in each lesion with at least five digits and sending it to the following function
        postDF = pd.DataFrame(list(map(np.ravel, postSplit)))   #Turning the returned arrays into a dataframe, where each array (previously lesion) is a row
        toOHE = [f"L{i}Site", f"L{i}Type", f"L{i}Subtype", f"L{i}SpecificCode"] #Renaming columns for readability and ease of dropping
        postDF.columns = toOHE  #^
        OHEncoded = pd.DataFrame(OHEncoder.fit_transform(postDF[toOHE]))    #OHE the newly made columns of lesion info
        OHEncoded.index = X.index   #Indexing the columns
        OHEncoded.columns = [f"L{i}_{y}" for y in range(0,len(OHEncoded.columns))]  #Naming the new columns so each throughout the loop are unique
        X = pd.concat([X, OHEncoded], axis=1)  #Adding the OHE encoded columns to the main dataframe
    X = X.drop(["lesion_1", "lesion_2", "lesion_3"], axis=1)    #Dropping the lesion columns as they are no longer necessary

    #Adding my own features
    #In an attempt to create a better differentiation between euthanized and died
    #Using the distribution bar charts found here: https://www.kaggle.com/code/kimtaehun/eda-and-baseline-with-multiple-models
    X["Pulse_Range"] = np.where((X["pulse"] > 80) | (X["pulse"] < 96), 0, 1)  #Maj euthanized  Increased CV by about 0.05 when combined with the one's that don't change by themselves
    #X["LT_Three_NRPh"] = np.where((X["nasogastric_reflux_ph"] < 3), 0, 1)    #Euthanized   drops CV by about 0.08
    X["GT_Six_NRPh"] = np.where((X["nasogastric_reflux_ph"] > 6.5), 0, 1)    #Maj died  doesn't change CV

    X["Respiratory_rate_range"] = np.where((X["respiratory_rate"] > 23) & (X["respiratory_rate"] < 30), 0, 1) #Euthanized   doesn't change CV
    #X["Abdomo_Protein_Range"] = np.where((X["abdomo_protein"] > 1.5) & (X["abdomo_protein"] < 2.2), 0, 1) #Euthanized drops CV by about 0.08

    
    return X

def properlySplittingLesions(L: str):   #00000          02209           21310   
    if L[:2] in ["00", "11"]:   #        00 0 0 0       doesn't eval    doesn't eval
        o,s,t,f = L[:2], L[2], L[3], L[4]
    elif L[0] == "0":           #        evals above    2 2 0 9         doesn't eval
        o,s,t,f = L[1], L[2], L[3], L[4]
    else:                       #        evals above    evals above     2 1 3 10
        o,s,t,f = L[0], L[1], L[2], L[3:]
    return [o, s, t, f]

def dataPrepSecond(X):  #Done seperate from the test and train
    #Ensuring every data point has become numerical by this point
    X = X.apply(pd.to_numeric)

    #Feature Scaling columns that were provided as numerical
    Stand = ["rectal_temp", "respiratory_rate", "abdomo_protein", "pulse", "nasogastric_reflux_ph", "packed_cell_volume"]
    #Standard Scaling
    scaler = StandardScaler()
    for i in Stand:
        model = scaler.fit(X[[f"{i}"]])
        X[f"{i}"] = model.transform(X[[f"{i}"]])
    """
    #L2 Scaling
    scaler = Normalizer(norm="l2")
    LTwo = ["pulse", "respiratory_rate", "abdomo_protein"]
    for i in LTwo:
        model = scaler.fit(X[[f"{i}"]])
        X[f"{i}"] = model.transform(X[[f"{i}"]])
    """
    #MinMax and log transformation
    scaler = MinMaxScaler()
    MinMax = ["pulse", "respiratory_rate", "abdomo_protein", "total_protein"]
    for i in MinMax:
        model = scaler.fit(X[[f"{i}"]])
        X[f"{i}"] = model.transform(X[[f"{i}"]])
        X[f"{i}"] = X[f"{i}"] + 1
        X[f"{i}"] = np.log(X[f"{i}"] + 1)
    #Boxcox
    BoxCox = MinMax
    for i in BoxCox:
        X[f"{i}"] = power_transform(X[[f"{i}"]], method='box-cox')
    #This normalizes all the data except Pulse, nasogastric_reflux_ph, and packed_cell_volume (as they contain 0's. Each are linear)
    
    X.columns = X.columns.astype(str)
    return X

def dataVisualization(X, y):
    """
    #MI Scoring
    mi_scores = mutual_info_regression(X,y)
    for i in range(0, len(mutual_info_regression(X,y))):
        print(f"{list(X.columns)[i]}: {mi_scores[i]}")
    """
    """
    for i in range(0, len(X.columns)):
        plt.plot(X[f"{list(X.columns)[i]}"], y, "ro")
        plt.ylabel("outcome")
        plt.xlabel(f"{list(X.columns)[i]}")
        plt.show()
    """
    #Normal distribution chart to find which feature follows the Gaussian distribution (those that don't should be normalized)
    #https://stackoverflow.com/questions/71287607/how-to-make-a-normal-distribution-graph-from-data-frame-in-python
    numericalFeatures = ["rectal_temp", "pulse", "respiratory_rate", "nasogastric_reflux_ph", "packed_cell_volume", "abdomo_protein", "total_protein"]
    
    #Testing with just one numerical feature
    numericalFeatures = ["rectal_temp"]
    y = pd.DataFrame(y)
    #Adding the outcome column back to the feature dataframe for ease of data visualization
    X["outcome"] = y["outcome"]
    #Want a stacked barchart displaying lived, died, euthanized as well as the distribution chart (so I can see where the cut offs are for numerical features between died and euthanized)
    #Need to better distinguish euthanized and died
    #https://www.kaggle.com/competitions/playground-series-s3e22/discussion/438889
    """
    for i in numericalFeatures:
        #Collecting mean and standard deviation
        mean = np.mean(X[i])
        std = np.std(X[i])
        #Calculating probability density
        ProbDens = stats.norm.pdf(X[i].sort_values(), mean, std)
        #Drawing the plot
        plt.plot(X[i].sort_values(), ProbDens)
        plt.xlabel(f"{i}")
        plt.ylabel("Frequency")
        plt.grid(color = "black", linestyle="--")
        plt.show()
    """
    outcomes = [2,1,0]
    for i in numericalFeatures:
        for j in outcomes:
            FWO = X.loc[X["outcome"]==j, i] #Feature with outcome
            print(j, "\n", FWO)
            mean = np.mean(FWO)
            std = np.std(FWO)
            ProbDens = stats.norm.pdf(FWO.sort_values(), mean, std)
            plt.bar(FWO, ProbDens)
            plt.plot(FWO, ProbDens)
        #Art/ Legend/ Showing plot
        plt.xlabel(i)
        plt.ylabel("Frequency")
        plt.grid(color = "black", linestyle="--", linewidth = 0.5)
        green_patch = mpatches.Patch(color="green", label="lived")
        orange_patch = mpatches.Patch(color="orange", label="died")
        blue_patch = mpatches.Patch(color="blue", label="euthanized")
        plt.legend(handles=[green_patch, orange_patch, blue_patch])
        plt.show()
    
    #https://towardsdatascience.com/100-stacked-charts-in-python-6ca3e1962d2b
    return 0

##################################################################################################################################################################################################

if __name__ == "__main__":
    #Determing if the run is a test or a submission
    kaggleSub = False

    #Reading in the data, creating the validation set, and building the feature set
    data_train = pd.read_csv("/Users/nwallace/Library/CloudStorage/OneDrive-EightElevenGroup/Desktop/MiscCoding/PythonML/HorseHealthOutcome/train.csv") #Reading in training data
    #Transforming the categorical outcome column into a numerical column 
    encoder = OrdinalEncoder(categories=[["euthanized", "died", "lived"]])
    data_train["outcome"] = encoder.fit_transform(data_train.loc[:,["outcome"]])

    #Selecting models
#    model = XGBClassifier(n_estimators = 100000, learning_rate=0.006, n_jobs=8, nthread=4, max_depth=14, booster="gbtree", tree_method="exact")
    #Before BoxCox: Gets worse after epoch 123, n_estimators=10000, learningRate=0.05, maxDepth of 4 (0.40878 +- 0.63506 )          After BoxCox: same as before (0.40878 +- 0.63762) 0.72469
#    model = OneVsRestClassifier(SVC())  #Before BoxCox: 0.6639        After BoxCox: 0.61538
#    model = GaussianNB()    #Before BoxCox: 0.41295 (But some of the features are linear, not Guassian (as seen with the data visualization function))       After BoxCox: 0.39676
#    model = LogisticRegression(random_state=0, max_iter=100000, warm_start=True)  #Before BoxCox: 0.736842 with Max_iter=100000       After BoxCox: 0.728744
    #Want to use RBM? Look here: https://scikit-learn.org/stable/auto_examples/neural_networks/plot_rbm_logistic_classification.html
    #I assume this actually overfitting as some of the data is Guassian formated and other pieces are linear
#    model = MLPClassifier(random_state=1, max_iter=10000, solver="adam")  #Before BoxCox (adam): 0.716599       After BoxCox (adam): 0.73279
    model = RandomForestClassifier(n_estimators = 12000, n_jobs=8, random_state=43, criterion="log_loss", max_features="log2", warm_start=True)
#    model = CatBoostClassifier(depth=10)
#    model = GradientBoostingClassifier(loss="log_loss", learning_rate=0.05, max_depth=6)
    #Same CV with
    #n_estimators=12000, random_state=43
    #the above^ and changing the defaults of the following two parameters criterion="log_loss" max_features="log2"

    #Testing
    if(not kaggleSub):
        #Data Prep
        yTrain = data_train["outcome"]    #Selecting validation set
        XTrain = data_train.drop(["outcome"], axis = 1)   #Selecting basic features
        #Changing feature set and displaying data
        XTrain = dataPrepFirst(XTrain)
        XTrain.columns = XTrain.columns.astype(str)
        #Creating test train split
        XTr, XTe, yTr, yTe = train_test_split(XTrain, yTrain, test_size=0.2, random_state=0, stratify=yTrain)
        XTr = dataPrepSecond(XTr)
        XTe = dataPrepSecond(XTe)
#        dataVisualization(XTr.copy(), yTr.copy())
        #^ It is imperative I standardized/ normalize/ shape the data after the split to prevent data leakage from occurring (especially with the boxcox preprocessing technique)
#        model.fit(XTr, yTr, eval_metric="mlogloss", eval_set=[(XTr, yTr), (XTe, yTe)], verbose=True, early_stopping_rounds=5)
        model.fit(XTr, yTr)
        predicts = pd.DataFrame(model.predict(XTe))
        print(f1_score(y_true= yTe, y_pred= predicts, average= "micro"))
        XTr.to_csv("/Users/nwallace/Desktop/MiscCoding/PythonML/HorseHealthOutcome/trainingData.csv", index=False)

    #Submitting
    if(kaggleSub):
        #Reading in test data
        data_test = pd.read_csv("/Users/nwallace/Library/CloudStorage/OneDrive-EightElevenGroup/Desktop/MiscCoding/PythonML/HorseHealthOutcome/test.csv") #Reading in testing data
        df_testID = data_test["id"] #Copying id to concat later
        
        #Prepping training data
        data_train_val = data_train["outcome"]
        data_train = data_train.drop(["outcome"], axis=1)
        #Combing test and train data so normalization and scaling match for the whole dataset
        data_TrTe = pd.concat(([data_train, data_test]))    #Combining both data sets
        data_TrTe = dataPrepFirst(data_TrTe)    #Prepping both data sets together
        data_train = data_TrTe.iloc[:1235]  #Adding data_train back after it's been prepped
        data_test = data_TrTe.iloc[1235:]   #Adding data_test back after the data has been prepped
        #Scaling each data set seperatley
        data_train = dataPrepSecond(data_train)
        data_test = dataPrepSecond(data_test)
        #Prepping model
        data_train.columns = data_train.columns.astype(str)
        data_test.columns = data_test.columns.astype(str)
        model.fit(data_train, data_train_val)    #Fitting model
        
        #Testing the model
        predicts = pd.DataFrame(model.predict(data_test))
        OrdEncoder = OrdinalEncoder(categories=["euthanized", "died", "lived"])
        submission = pd.concat([df_testID, predicts], axis=1, join="inner")
        submission.columns = ["id", "outcome"]
        replacement = {0: "euthanized", 1:"died", 2:"lived"}
        for i in replacement:
            submission["outcome"] = submission["outcome"].replace(i,replacement[i])
    #https://stackoverflow.com/questions/26098710/rename-unnamed-column-pandas-dataframe
        print(submission.head())
        print(submission.columns)
        submission.to_csv("/Users/nwallace/Desktop/MiscCoding/PythonML/HorseHealthOutcome/submission_9.csv", index=False)



'''
Notes:
    Steps:
        *1. Transform categorical data into numerical
            - Which should be OHE and which should be numerical transformations?
            -Create a feature for number of lesions and find the stats (use it to replace surgical_lesion column)
         2. Find MIR scores and explore some visualizations of the features
                rectal_temp: 0.001782257672679144
                pulse: 0.16171290180301323
                respiratory_rate: 0.03808389500275222
                temp_of_extremities: 0.07224226921620414
                peripheral_pulse: 0.06792291289496255
                mucous_membrane: 0.05702936583624041
                capillary_refill_time: 0.02947815670171572
                pain: 0.1631086794505423
                peristalsis: 0.04610629906384034
                abdominal_distention: 0.07959938450296011
                nasogastric_tube: 0.039865703399474484
                nasogastric_reflux: 0.01758850827337355
                nasogastric_reflux_ph: 0.10524354571579142
                rectal_exam_feces: 0.03573104806024663
                abdomen: 0.019760334918986544
                packed_cell_volume: 0.11744095260910914
                total_protein: 0.1528819454531556
                abdomo_appearance: 0.06365166153765855
                abdomo_protein: 0.16553232666858886
                lesion_1: 0.1951976391906145
                lesion_2: 0.017412445847818425
                lesion_3: 0.0
                outcome: 1.0634814619838893
                number_of_lesions: 0.06116532573078359
                0: 0.021866142297271907
                1: 0.02987881499695222
                2: 0.010792663139793657
                3: 0.032949549691334123
                4: 0.043217140934924014
                5: 0.01806157471169012
         3. Test!
Useful for data gathering:
        column = "age"
        uniqueValues = X[column].unique()
        X = X.replace(np.nan, "nan")
        print(uniqueValues)
        for i in uniqueValues:
            print(f"{i}/Lived\t\t: {len(X[(X[column]==f'{i}') & (X['outcome']=='lived')])} ({round((len(X[(X[column]==f'{i}') & (X['outcome']=='lived')]))/(len(X[(X[column]==f'{i}')]))*100)}%)")
            print(f"{i}/Died\t\t: {len(X[(X[column]==f'{i}') & (X['outcome']=='died')])} ({round((len(X[(X[column]==f'{i}') & (X['outcome']=='died')]))/(len(X[(X[column]==f'{i}')]))*100)}%)")
            print(f"{i}/Euthanized\t: {len(X[(X[column]==f'{i}') & (X['outcome']=='euthanized')])} ({round((len(X[(X[column]==f'{i}') & (X['outcome']=='euthanized')]))/(len(X[(X[column]==f'{i}')]))*100)}%)")
            print(f"{i} Total\t\t: {len(X[(X[column]==f'{i}')])}\n")
    - What I gather:
        + OHE    : age, surgery, cp_data
        + Ordinal: temp_of_extremities, peripheral_pulse, capillary_refill_time, pain, nasogastric_reflux, rectal_exam_feces
        + First numerical features: rectal_temp, pulse, respiratory_rate, nasogastric_reflux_ph, packed_cell, total_protein, lesions, abdomo_protein
            - rectal_temp: standard scaling
            - pulse: min-max scaling
            - respiratory_rate: standard scaling
            - nasogastric_reflux_ph: mix-max scaling
            - packed_cell_volume: min-max scaling
            - abdomo_protein: standard scaling
            - total_protein: L2 normalization
            - lesion 1: L2 normalization
            - lesion 2: L2 normalization
            - lesion 3: L2 normalization
            - NOTES: Need to find which of these don't follow the guasian distribution using a normal distribution chart (that will tell me which should be transformed using normalization)

    Submissions:
        First (XGBOOST):
            Test: 0.728744
            Submission: 0.50609
            NOTES: Caused by overfitting the model. Need to fit root of overfitting (Google "possible causes of overfitting a model")
                https://aws.amazon.com/what-is/overfitting/
                https://practicaldatascience.co.uk/machine-learning/how-to-avoid-model-overfitting-with-early-stopping-rounds
                ^ USE THIS
        Second(RandomForestClassifier):
            Test: 0.753036
            Submission: 0.46341
            NOTES: Saw more overfitting when using random forest classifier. Maybe I'll try keeping the Hospital number and use OHE for it
                https://www.kaggle.com/datasets/yasserh/horse-survival-dataset
                Need to study up on this information; should change lesion to OHE, maybe count the hospital number to find horses that show up more than once,
                    cp_data isn't extremely useful as it says in the link above (should probably be removed)
                    Actually, doing this for hospital number won't be useful as one horse in particular "dies" 30+ times. I think it's better to remove it.
                    Also, should probably normalize the test and train together, rather than seperate
        Third(XGBoost):
            Test: 0.744939
            Submission: 0.4878
            NOTES: I combined the training data and testing data when normalizing/ scaling. I also tested the limits of the XGBoost to find when logloss gets worse
                    5 times in a row, then used that as the cut-off. It's unfortunate that the results were worse, I'm running out of things to try and I was quite confident these changes would see
                    significant increases in logloss. Onto re-righting my wrongs with the lesion data
            What is needed to do this:
                Add leading 0's to each lesion column. If the first number is 0 all subsequent columns for that lesion will be 0. 
                I'll also be reverting the train and test concatination before prepping the data as that wouldn't be an option with real-world data
            NOTES: Saw worse score when OHE each of the lesion data points in testing. I think this is due to the large number of OHE columns causing too much noise
            Might be time to try some new models: OneVsRest (with SVC (0.6639)), Multilayer Perceptron, Naive Bayes, Logistic Regression

            Linear: pulse, nasogastric_reflux_ph, packed_cell_volume
            Guassian: rectal_temp, abdomo_protein (close), 
            LogNormal: respiratoy_rate, abdomo_protein, total_protein(ish)
        Fourth(MLPClassifier):
            Test: 0.73279
            Submission: 0.50609
        Fifth(LogisticRegression):
            Test: 0.728744
            Submission: 0.4756
            NOTES: I want to try eliminating some noise, maybe getting rid of abdomo protein and the lesion data, then test

            I just realized the submission should be Lived, DIED, Euthanized not Lived, DEAD, Euthanized. There goes a few subs :/
        Sixth(RandomForestClassifier):
            Test: 0.748987
            Submission: 0.78658
            NOTES: I want to find/ create some features that better distinguish died and euthanized horses. I tried leaving out the OHE lesion data during tests and saw CV score drop by
                about 1%, so I've decided to leave it in (even if it might be considered noise).
        Seventh(LogisticRegression):
            Test: 0.736842
            Submission: 0.76829
            NOTES: Will add a feature for...
                + pulse between 80 and 95
                + nasogastric_reflux_ph < 3 (euthanized)
                + nasogastric_reflux_ph > 6.5 (died)
                + total_protein < 10 or > 75 
                + respiratory_rate between 23 and 30
                Adding these lowered my CV by about a percent :/
                When training the submission should see 0.34146 Died, 0.19513 Euthanized, and 0.46341 Lived based on... https://www.kaggle.com/competitions/playground-series-s3e22/discussion/438889
        Eight(RandomForestClassifier):
            Test: 0.75303
            Submission: 0.78658
            NOTES: I just want to experiment with some other models for a bit to see if I can find any improvements in CV/ submissions scores
        Ninth(CatboostClassifier):
            Test: 0.74898
            Submission: 0.76829
'''