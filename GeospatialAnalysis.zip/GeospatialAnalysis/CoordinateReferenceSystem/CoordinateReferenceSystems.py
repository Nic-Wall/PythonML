import pandas as pd
import geopandas as gpd
import os
import matplotlib.pyplot as plt

#Loading Data
regions = gpd.read_file(f"{os.getcwd()}/CoordinateReferenceSystem/Map_of_Regions_in_Ghana.shp")
print(regions.crs)
"""
How are CRS systems read? With the reference codes from the European Petroleum Survey Group (EPSG). This GeoDataFrame uses 32630 which is commonly called "mercator" projection.
This projection preserves angles (making it useful for sea navigation) and slightly distorts area. When creating a GeoDataFrame from a CSV file we have to set the CRS.
EPSG 4326 corresponds to coordinates in latitude and longitude.
"""
#Creating a DataFrame with the health facilities in Ghana
facilitiesDF = pd.read_csv(f"{os.getcwd()}/CoordinateReferenceSystem/health_facilities.csv")
#Convert it to a GeoDataFrame
facilities = gpd.GeoDataFrame(facilitiesDF, geometry = gpd.points_from_xy(facilitiesDF.Longitude, facilitiesDF.Latitude))
#Set the coordinate reference system (CRS) to EPSG 4326
facilities.crs = {"init": "EPSG:4326"}
#Viewing the first five rows of the GeoDataFrame
facilities.head()   #Need to sort out the error
ax = regions.plot(figsize = (8,8), color="whitesmoke", linestyle = ":", edgecolor = "black")
facilities.to_crs(epsg=32630).plot(markersize=1, ax=ax)
#The Latitude and Longitude columns can remain unchanged with the use of hte to_crs() method, as it only changes the geometry column
print(facilities.to_crs(epsg=32630).head())
"""
If the EPSG code is not available in GeoPandas, one can change the CRS with what's known as the "proj4 string" of the CRS.
The string to convert latitude/ longitude coordinates is...
+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs
"""
#Changing the CRS to EPSG 4326
print(regions.to_crs("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs").head())
#One can view the x and y coordinates on their own with...
print(facilities.geometry.head().x)
#One can also acquire the length of a LineString with "length" or the area of a polygon with "area"
#Calculating the area (in meters squared) of each polygon in the GeoDataFrame
regions.loc[:, "Area"] = regions.geometry.area / 10**6
print(f"Area of Ghana: {regions.Area.sum()} square kilometers")
print(f"CRS: {regions.crs}")
print(regions.head())
plt.show()