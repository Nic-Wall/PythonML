"""
Shapefile, GeoJSON, KML, GPKG are just a few deospatial file formats. This course focuses on the most common, shapefile.
All of the above can be read with gpd.read_file().
"""
#Imports
import pandas as pd
import geopandas as gpd
import os
import matplotlib.pyplot as plt
#Reading in the data
fullData = gpd.read_file(f"{os.getcwd()}/YourFirstMap/Decptsofinterest.shp")
print(fullData.head())
"""
Every command that works with Pandas data frames works with geopandas dataframes (go figure)!
"""
#print(type(fullData))
print(fullData.columns)
#For instance, one can select subsets of data
data = fullData.loc[:, ["FACILITY","REGION","geometry"]].copy()
print(fullData.geometry.value_counts()) #Based on this line I see there are no Polygons, so I can't complete the rest of the
#tutorial :/
'''
#How many lands of each type are there?
print(fullData.FACILITY.value_counts())
#One can also use iloc and isin to select subsets of data
high_peaks = data.loc[data.FACILITY.isin(["HIGH PEAKS WILDERNESS"])].copy()
print(high_peaks.head())
"""
Every GeoDataFrame contains a special "geometry" column that contains all of the geometric objects that are displayed when
plot is called
"""
print(high_peaks.geometry.head())
high_peaks.plot()
plt.show()
'''