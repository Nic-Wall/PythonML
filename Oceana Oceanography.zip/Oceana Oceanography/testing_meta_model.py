#Imports
import catboost
import math
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GroupShuffleSplit
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import PoissonRegressor
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.linear_model import ElasticNet
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_squared_error
import seaborn as sns
import matplotlib.pyplot as plt
import xgboost

x_tr = pd.read_csv("/Users/nwallace/Desktop/MiscCoding/PythonML/Oceana Oceanography/train_meta_model_features.csv")
x_te = pd.read_csv("/Users/nwallace/Desktop/MiscCoding/PythonML/Oceana Oceanography/test_meta_model_features.csv")

y = "WVHT(m)"
y_tr = x_tr[y]
x_tr.drop(columns= [y], inplace= True)
y_te = x_te[y]
x_te.drop(columns= [y], inplace= True)

#To beat: 0.08698
solver = ["auto", "svd", "cholesky", "sparse_cg", "lsqr", "sag", "lbfgs"]
#I suggest just giving it a go with LinearRegression and see what the real results are

model = LinearRegression()  #0.08731
#model = catboost.CatBoostRegressor(iterations= 50000, learning_rate= 0.0001, depth= 11, loss_function= "RMSE", reg_lambda= 8, early_stopping_rounds= 30, silent= True)  #0.08870
#model = xgboost.XGBRegressor(n_estimators= 25000, learning_rate= 0.0001, booster= "gbtree", subsample= 0.8, max_depth= 12)
#model = Ridge(tol= 0.0001, alpha= 0.5, max_iter= 35000)
#model = ExtraTreesRegressor(n_estimators= 15000, max_depth= 12, min_samples_split= 6, min_samples_leaf= 2)
#model = SVR(kernel= "linear", degree= 4, tol= 0.0001, C= 3) #0.087805
#model = PoissonRegressor(alpha= 0.0001, max_iter= 40000, tol= 0.0001)   #0.102630
#model = KNeighborsRegressor(n_neighbors= 15, leaf_size= 50, p= 1)   #0.089132
#model = ElasticNet(alpha= 1, l1_ratio= 0.25, max_iter= 1000, tol= 0.000005)    #0.387
#model = Lasso(alpha= 3, max_iter= 15000, tol= 0.0001)   #same as net
model.fit(x_tr, y_tr)
predictions = model.predict(x_te)
np.around(predictions, decimals= 2)
MSE = mean_squared_error(y_te, predictions, squared= False)
print(MSE)

#Try normalizing data first
#Try running two models and taking the average